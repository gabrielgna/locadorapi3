/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Entidades.Funcionario;
import Persistencias.AdapterCliente;
import Persistencias.PFuncionarios;

/**
 *
 * @author Jorgin
 */
public class NFuncionarios {

    private PFuncionarios per;

    public NFuncionarios() {
        per = new PFuncionarios();
    }

    public void salvar(Funcionario parametro) throws Exception {

        if (parametro.getNome() == "") {
            throw new Exception("É necessário preencher o nome");
        }

        if (parametro.getCpf() == "") {
            throw new Exception("É necessário preencher o cpf");
        }

        if (parametro.getUsuario() == "") {
            throw new Exception("É necessário preencher o campo nome de Usuário");
        }

        if (parametro.getSenha() == "") {
            throw new Exception("É necessário preencher o campo Senha");
        }

        if (parametro.getId() == 0) {
            String incluir = "";
            incluir += parametro.getNome() + ";";
            incluir += parametro.getCpf() + ";";
            incluir += parametro.getSexo() + ";";
            incluir += parametro.getUsuario() + ";";
            incluir += parametro.getUsuario() + ";";

            new AdapterCliente().Adaptar(incluir);
        } else {
            per.alterar(parametro);
        }

    }

    public void excluir(int id) throws Exception {
        per.excluir(id);
    }

    public Funcionario consultar(int id) throws Exception {
        return per.consultar(id);
    }
}
