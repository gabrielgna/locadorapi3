package Negocio;

import Entidades.Aluguel;
import Entidades.Devolucao;
import Entidades.Pedido;
import Persistencias.PDevolucao;
import Persistencias.PFilme;
import Persistencias.PPedido;
import javax.swing.JOptionPane;

/**
 *
 * @author 443384
 */
public class NDevolucao {

    public NDevolucao() {
    }

    public void Salvar(Devolucao devolucao) {
        if (devolucao.getCliente().getId() == 0) {
            JOptionPane.showMessageDialog(null, "Sem Cliente No Pedido");
        }
        else if(devolucao.getListaItens().size()==0){
            JOptionPane.showMessageDialog(null, "Cliente não tem filmes para devolver");
        }
        else {
            try {
                //altera a disponibilidade no banco
                for (int i = 0; i < devolucao.getListaItens().size(); i++) {
                    new PFilme().Devolucao(devolucao.getListaItens().get(i).getId());
                }
                //cadastra na tabela devolucao
                new PDevolucao().incluir(devolucao);
                JOptionPane.showMessageDialog(null, "Bem Sucedido!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
    }

}
