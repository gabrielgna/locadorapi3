package Negocio;

import Entidades.Filme;
import Entidades.Filme;
import Persistencias.PFilme;
import javax.swing.JOptionPane;

/**
 * @author Gabriel Oliveira
 */
public class NCadastroFilme {

    private PFilme per;

    public NCadastroFilme() {
        per = new PFilme();
    }

    public void IncluiFilmeAluguel(Filme filme, int Quantidade) throws Exception {
        if (filme.getValoraluguel() <= 0) {
            throw new Exception("Digite Valor de Locacao Valido");
        } else if (filme.getNome().equalsIgnoreCase("")) {
            throw new Exception("Digite Nome do Filme de Locacao Valido");
        } else {
            for (int i = 1; i <= Quantidade; i++) {
                per.incluir(filme);
            }
        }
    }

    public void IncluiFilmeVenda(Filme filme, int Quantidade) throws Exception {
        if (filme.getValorvenda() <= 0) {
            throw new Exception("Digite Valor de Locacao Valido");
        } else if (filme.getNome().equalsIgnoreCase("")) {
            throw new Exception("Digite Nome do Filme de Locacao Valido");
        } else {
            for (int i = 1; i <= Quantidade; i++) {
                per.incluir(filme);
            }
        }
    }

}
