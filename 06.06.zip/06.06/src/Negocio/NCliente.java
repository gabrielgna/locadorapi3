/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Entidades.Cliente;
import Persistencias.AdapterCliente;
import java.sql.SQLException;
import java.util.List;
import Persistencias.PCliente;

/**
 *
 * @author aluno
 */
public class NCliente {

    private PCliente per;

    public NCliente() {
        per = new PCliente();
    }

    public void salvar(Cliente parametro) throws Exception {

        if (parametro.getNome() == "") {
            throw new Exception("É necessário preencher o nome");
        }

        if (parametro.getCpf()== "") {
            throw new Exception("É necessário preencher o cpf");
        }
        
        if (parametro.getDatadenascimento()== "") {
            throw new Exception("É necessário preencher a data de nascimento");
        }
        
        if(parametro.getId() == 0){
            String incluir="";
            incluir+=parametro.getNome()+";";
            incluir+=parametro.getEndereco()+";";
            incluir+=parametro.getTelefone()+";";
            incluir+=parametro.getCpf()+";";
            incluir+=parametro.getEmail()+";";
            incluir+=parametro.getDatadenascimento()+";";
            incluir+=parametro.getSexo()+";";
            new AdapterCliente().Adaptar(incluir);
        }else{
            per.alterar(parametro);
        }
            

    }
    
    public void excluir(int id) throws Exception{
        per.excluir(id);
    }
    
    public Cliente consultar(int id) throws Exception{
        return per.consultar(id);
    }
    
    public List<Cliente> listar() throws Exception{
        return per.listar();
    }
    
    
    
    
    

}
