package Negocio;

import Entidades.Lista;
import Entidades.Pedido;
import Persistencias.PFilme;
import Persistencias.PPedido;
import Telas.TelaSatisfacao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 443384
 */
public class NPedido {

    public NPedido() {
    }

    public void Salvar(Pedido pedido) {
        if (pedido.getListaItens().size() == 0) {
            JOptionPane.showMessageDialog(null, "Pedido Vazio");
        } else if (pedido.getCliente().getId() == 0) {
            JOptionPane.showMessageDialog(null, "Sem Cliente No Pedido");
        } else {
            try {
                //altera a disponibilidade no banco
                for (int i = 0; i < pedido.getListaItens().size(); i++) {
                    new PFilme().alterarNaoDisponivel(pedido.getListaItens().get(i).getId());
                }
                //cadastra na tabela pedidos
                new PPedido().incluir(pedido);

                TelaSatisfacao tela = new TelaSatisfacao();
                tela.setVisible(true);

                JOptionPane.showMessageDialog(null, "Bem Sucedido!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
    }

    public List Listar() {

        Lista lista = new Lista();
        List<Pedido> array = new ArrayList<>();
        try {
            array = new PPedido().listar();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        for (int i = 0; i < array.size(); i++) {
            lista.insereInicio(array.get(i));
        }

        return lista.mostraLista();

    }

}
