package Negocio;

import Entidades.Aluguel;
import Entidades.Pedido;
import Entidades.Reserva;
import Persistencias.PFilme;
import Persistencias.PPedido;
import javax.swing.JOptionPane;

/**
 *
 * @author 443384
 */
public class NReserva {

    public NReserva() {
    }

    public void Salvar(Reserva reserva) {
        if (reserva.getListaItens().size() == 0) {
            JOptionPane.showMessageDialog(null, "Pedido Vazio");
        } else if (reserva.getCliente().getId() == 0) {
            JOptionPane.showMessageDialog(null, "Sem Cliente No Pedido");
        } else {
            try {
                //altera a disponibilidade no banco
                for (int i = 0; i < reserva.getListaItens().size(); i++) {
                    new PFilme().Reserva(reserva.getListaItens().get(i).getId(), reserva.getCliente().getId());
                }
                //cadastra na tabela pedidos
                //new PPedido().incluir(aluguel);
                JOptionPane.showMessageDialog(null, "Bem Sucedido!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
    }

}
