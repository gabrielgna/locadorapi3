/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 *
 * @author eugenio
 */
public class dez extends Cupom {

    public dez() {
        Nome = "Dez %";
        porcentagem = 10;

    }
}
