package Entidades;

import java.util.ArrayList;
import java.util.List;

public class Lista {

    private No inicio;
    private No fim;

    //criar uma lista vazia
    public Lista() {
        inicio = null;
        fim = null;
    }

    //verifica se a lista está vazia
    public boolean eVazia() {
        return inicio == null;
    }

    //insere um No no início da lista
    public void insereInicio(Pedido aluno) {
        No no = new No(aluno, null);
        if (eVazia()) {
            inicio = no;
            fim = no;
        } else {
            no.setProx(inicio);
            inicio = no;
        }
    }

    //insere um No no início da lista
   /*
    public void insereFim(Aluno aluno) {
        No no = new No(aluno, null);
        if (eVazia()) {
            inicio = no;
            fim = no;
        } else {
            fim.setProx(no);
            fim = no;
        }
    }

    //insere ordenado
    public void insereOrdenado(Aluno aluno) {
        No ant, atual;
        if (eVazia()) {
            insereFim(aluno);
        } else {
            ant = null;
            atual = inicio;
            while (atual != null && atual.getInfo().getMatricula() < aluno.getMatricula()) {
                ant = atual;
                atual = atual.getProx();
            }
            if (ant == null) { // será o primeiro
                insereInicio(aluno);
            } else {
                if (atual == null) { // será o último
                    insereFim(aluno);
                } else {
                    No no = new No(aluno, null);
                    ant.setProx(no);
                    no.setProx(atual);
                }
            }
        }
    }

*/
    //remove elemento da lista
    //recebe um numero - chave
    //outra maneira ==> retornaro objeto removido
    public boolean removeElemento(int numero) {
        No ant, atual;

        ant = null;
        atual = inicio;
        while (atual != null && numero != atual.getInfo().getId()) {
            ant = atual;
            atual = atual.getProx();
        }
        if (atual == null) {
            return false;
        }

        if (inicio == fim) {
            inicio = null;
            fim = null;
        } else {
            if (ant == null) {
                inicio = atual.getProx();
                atual.setProx(inicio);
            } else {
                ant.setProx(atual.getProx());
                atual.setProx(inicio);
            }

        }

        return true;
    }

    //mostra lista
    public List mostraLista() {
        if (eVazia()) {
            System.out.println("Lista vazia");
            return null;
        }
        No aux = inicio;
        List<Pedido> lista = new ArrayList<>();

        while (aux != null) {
            lista.add(aux.getInfo());
            aux = aux.getProx();

        }
        return lista;
    }
/*
    //Concatena lista
    public Lista concatenaLista(Lista l1, Lista l2) {
        Lista l3 = new Lista();
        No aux = l1.inicio;
        while (aux != null) {
            l3.insereFim(aux.getInfo());
            aux = aux.getProx();
        }
        aux = l2.inicio;
        while (aux != null) {
            l3.insereFim(aux.getInfo());
            aux = aux.getProx();
        }
        return l3;
    }

    // busca elemento na lista
    //retorna null, caso o elemento não existe na lista
    //caso contrário, retorna o objeto.
    public Aluno busca(int chave) {
        if (eVazia()) {
            return null;
        }
        No aux = inicio;
        while (aux != null) {
            if (chave == aux.getInfo().getMatricula()) {
                return aux.getInfo();
            }
            aux = aux.getProx();
        }
        return null;
    }

*/
}
