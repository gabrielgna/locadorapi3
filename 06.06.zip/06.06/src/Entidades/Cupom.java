/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 *
 * @author eugenio
 */
public abstract class Cupom {
    //Atributos
    protected String Nome;
    protected double porcentagem;
        
    public String getNome(){return Nome;}
    public double getPorcentagem(){return porcentagem;}
   
}
