package Entidades;

public interface Observador {//OK
    public void atualizar(Cliente dados);

}