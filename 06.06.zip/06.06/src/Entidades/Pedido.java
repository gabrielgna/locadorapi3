/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HeuberLima
 */
public class Pedido {
    
    private int id;
    private Date data;
    private double valorTotal;
    private Filme filme;
    
    private Cliente cliente;
    private List<Filme> listaItens;

    public Pedido() {
        cliente = new Cliente();
        listaItens = new ArrayList<>();
    }

    public Pedido(Cliente cliente, List<Filme> listaItens) {
        this.cliente = cliente;
        this.listaItens = listaItens;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int Id) {
        this.id = Id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
    
    public void setValorTotalAcumulando(double valor) {
        this.valorTotal += valor;
    }
    
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<Filme> getListaItens() {
        return listaItens;
    }

    public void setListaItens(List<Filme> listaItens) {
        this.listaItens = listaItens;
    }
       
    
}
