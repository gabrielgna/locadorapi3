package Entidades;

/**
 * @author Gabriel Oliveira
 */
public class Filme {

    private int id;
    private String nome;
    private String autor;
    private String datalancamento;
    private double valoraluguel;
    private double valorvenda;
    private String pvenda;
    private String palguel;
    private String datavenda;
    private String acontecimento;
    private String disponivel;
    private int Id_cliente_aluguel;
    private int DiasContratados;

    public Filme() {
        id = 0;
        nome = "";
        autor = "";
        datalancamento = "";
        valoraluguel = 0.0;
        valorvenda = 0.0;
        pvenda = "";
        palguel = "";
        datavenda = "";
        acontecimento = "";
        disponivel = "";
        Id_cliente_aluguel = 0;
    }

    public void IncluirAluguel(String nome, String autor, String datalancamento, double valoraluguel) {
        this.nome = nome;
        this.autor = autor;
        this.datalancamento = datalancamento;
        this.valoraluguel = valoraluguel;
        this.palguel = "SIM";
        this.disponivel = "SIM";
        this.DiasContratados = 0;

    }

    public void IncluirVenda(String nome, String autor, String datalancamento, double valorvenda) {
        this.nome = nome;
        this.autor = autor;
        this.datalancamento = datalancamento;
        this.valorvenda = valorvenda;
        this.pvenda = "SIM";
        this.disponivel = "SIM";
    }

    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the autor
     */
    public String getAutor() {
        return autor;
    }

    /**
     * @param autor the autor to set
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }

    /**
     * @return the datalancamento
     */
    public String getDatalancamento() {
        return datalancamento;
    }

    /**
     * @param datalancamento the datalancamento to set
     */
    public void setDatalancamento(String datalancamento) {
        this.datalancamento = datalancamento;
    }

    /**
     * @return the valoraluguel
     */
    public double getValoraluguel() {
        return valoraluguel;
    }

    /**
     * @param valoraluguel the valoraluguel to set
     */
    public void setValoraluguel(double valoraluguel) {
        this.valoraluguel = valoraluguel;
    }

    /**
     * @return the valorvenda
     */
    public double getValorvenda() {
        return valorvenda;
    }

    /**
     * @param valorvenda the valorvenda to set
     */
    public void setValorvenda(double valorvenda) {
        this.valorvenda = valorvenda;
    }

    /**
     * @return the pvenda
     */
    public String getPvenda() {
        return pvenda;
    }

    /**
     * @param pvenda the pvenda to set
     */
    public void setPvenda(String pvenda) {
        this.pvenda = pvenda;
    }

    /**
     * @return the palguel
     */
    public String getPalguel() {
        return palguel;
    }

    /**
     * @param palguel the palguel to set
     */
    public void setPalguel(String palguel) {
        this.palguel = palguel;
    }

    /**
     * @return the datavenda
     */
    public String getDatavenda() {
        return datavenda;
    }

    /**
     * @param datavenda the datavenda to set
     */
    public void setDatavenda(String datavenda) {
        this.datavenda = datavenda;
    }
    
    public String getAcontecimento() {
        return acontecimento;
    }

    public void setAcontecimento(String acontecimento) {
        this.acontecimento = acontecimento;
    }

    public String getDisponivel() {
        return disponivel;
    }

    public void setDisponivel(String Disponivel) {
        this.disponivel = Disponivel;
    }

    public int getId_cliente_aluguel() {
        return Id_cliente_aluguel;
    }

    public void setId_cliente_aluguel(int Id_cliente_aluguel) {
        this.Id_cliente_aluguel = Id_cliente_aluguel;
    }

    public int getDiasContratados() {
        return DiasContratados;
    }

    public void setDiasContratados(int DiasContratados) {
        this.DiasContratados = DiasContratados;
    }

    @Override
    public String toString() {
        return this.nome;
    }

}
