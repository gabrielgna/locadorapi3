/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Entidades;

/**
 *  Fornece uma interface para acrescentar e remover objetos
 *  permitindo incluir e retirar objetos observer.
 * @author eugeniojulio
 */
public interface Sujeito {//OK
    public void incluirObservador(Observador o);
    public void removerObservador(Observador o);
    public void notificarObservador();
}
