package Entidades;


public class No {
    private Pedido info;
    private No prox;

    public No(Pedido info, No prox) {
        this.info = info;
        this.prox = prox;
    }

    public Pedido getInfo() {
        return info;
    }

    public void setInfo(Pedido info) {
        this.info = info;
    }

    public No getProx() {
        return prox;
    }

    public void setProx(No prox) {
        this.prox = prox;
    }
    
}
