
package Entidades;

public class FabricaDeCupons {
    public static Cupom getCupom(String tipoDoCarro){
        Cupom obj = null;
        if(tipoDoCarro.equalsIgnoreCase("dez")){
            obj = new dez();
        }
        else if(tipoDoCarro.equalsIgnoreCase("vinte")){
            obj = new vinte();
        }       
                      
        return obj;
    }
    
}
