package Persistencias;

import Entidades.Cliente;

public class OrdenadoPorCpf extends PClienteTemplate {

    @Override
    public boolean ePrimeiro(Cliente cliente1, Cliente cliente2) {
        if (cliente1.getCpf().compareToIgnoreCase(cliente2.getCpf()) <= 0) {
            return true;
        } else {
            return false;
        }
    }

}
