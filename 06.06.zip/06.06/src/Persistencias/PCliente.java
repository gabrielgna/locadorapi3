/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencias;

import Entidades.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aluno
 */
public class PCliente {

    public void incluir(Cliente parametro) throws SQLException {

        //Cria a instrução SQL para a inserção no banco
        String sql = "INSERT INTO clientes (nome, telefone, endereco, email, datanascimento, cpf, sexo) "
                + " VALUES(?,?,?,?,?,?,?);";

        //Criando o objeto para a conexao
        Connection cnn = util.Conexao.getConexao();

        //Cria o objeto para executar os comandos no banco
        PreparedStatement prd = cnn.prepareStatement(sql);

        //Substitui as variveis do sql pelos valores passados
        //como parametro
        prd.setString(1, parametro.getNome());
        prd.setString(2, parametro.getTelefone());
        prd.setString(3, parametro.getEndereco());
        prd.setString(4, parametro.getEmail());
        prd.setString(5, parametro.getDatadenascimento());
        prd.setString(6, parametro.getCpf());
        prd.setString(7, parametro.getSexo());

        //Executa o comando
        prd.execute();

        //Recupera o id gerado
        String sql2 = "SELECT currval('clientes_id_seq') as id";

        Statement stm = cnn.createStatement();
        ResultSet rs = stm.executeQuery(sql2);

        if (rs.next()) {
            parametro.setId(rs.getInt("id"));
        }

        rs.close();
        cnn.close();

    }

    public void alterar(Cliente parametro) throws SQLException {

        String sql = "UPDATE clientes SET"
                + " nome = ?, telefone = ?, endereco = ?, email = ?, datanascimento = ?, cpf = ?, sexo = ?"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setString(1, parametro.getNome());
        prd.setString(2, parametro.getTelefone());
        prd.setString(3, parametro.getEndereco());
        prd.setString(4, parametro.getEmail());
        prd.setString(5, parametro.getDatadenascimento());
        prd.setString(6, parametro.getCpf());
        prd.setString(7, parametro.getSexo());

        prd.execute();
        cnn.close();

    }

    public void excluir(int id) throws SQLException {

        String sql = "DELETE FROM clientes"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, id);

        prd.execute();
        cnn.close();

    }

    public Cliente consultar(int id) throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT id, nome, telefone, endereco, email, datanascimento, cpf, sexo"
                + " FROM clientes "
                + " WHERE id = ?";

        PreparedStatement stm = cnn.prepareStatement(sql);
        stm.setInt(1, id);

        ResultSet rs = stm.executeQuery();

        Cliente cliente = new Cliente();
        if (rs.next()) {
            cliente.setId(rs.getInt("id"));
            cliente.setNome(rs.getString("nome"));
            cliente.setTelefone(rs.getString("telefone"));
            cliente.setEndereco(rs.getString("endereco"));
            cliente.setEmail(rs.getString("email"));
            cliente.setDatadenascimento(rs.getString("datanascimento"));
            cliente.setCpf(rs.getString("cpf"));
            cliente.setSexo(rs.getString("sexo"));

        }
        rs.close();
        cnn.close();

        return cliente;
    }

    public List<Cliente> listar() throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT id, nome, telefone, endereco, email, datanascimento, cpf, sexo "
                + " FROM clientes ";

        Statement stm = cnn.createStatement();

        ResultSet rs = stm.executeQuery(sql);

        List<Cliente> lista = new ArrayList<>();

        while (rs.next()) {
            Cliente cliente = new Cliente();
            cliente.setId(rs.getInt("id"));
            cliente.setNome(rs.getString("nome"));
            cliente.setTelefone(rs.getString("telefone"));
            cliente.setEndereco(rs.getString("endereco"));
            cliente.setEmail(rs.getString("email"));
            cliente.setDatadenascimento(rs.getString("datanascimento"));
            cliente.setCpf(rs.getString("cpf"));
            cliente.setSexo(rs.getString("sexo"));
            lista.add(cliente);
        }
        rs.close();
        cnn.close();

        return lista;
    }

}
