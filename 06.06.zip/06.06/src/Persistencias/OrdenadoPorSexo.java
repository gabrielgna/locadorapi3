package Persistencias;

import Entidades.Cliente;

public class OrdenadoPorSexo extends PClienteTemplate {

    @Override
    public boolean ePrimeiro(Cliente cliente1, Cliente cliente2) {
        if (cliente1.getSexo().compareToIgnoreCase(cliente2.getSexo()) <= 0) {
            return true;
        } else {
            return false;
        }
    }

}
