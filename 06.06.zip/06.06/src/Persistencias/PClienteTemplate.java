package Persistencias;

import Entidades.Cliente;
import Persistencias.PCliente;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

/**
 *
 * @author eugeniojulio
 */
public abstract class PClienteTemplate {

    //Metodo abstrato que ira compor o algoritmo de ordenacao da listagem
    public abstract boolean ePrimeiro(Cliente aluno1, Cliente aluno2);

    public Iterator<Cliente> ListagemDeClientesOrdenacao() throws Exception {
        try {
            ArrayList<Cliente> array = new ArrayList<Cliente>();
            //FileReader fr = new FileReader(nomeDoArquivo);
            //BufferedReader br  = new BufferedReader(fr);
            String linha = "";
            int pos = 0;
            for (Cliente cliente : new PCliente().listar()) {
                array.add(cliente);
                pos++;
            }

            //algoritmo de Ordenação
            for (int i = 0; i < array.size(); i++) {
                for (int j = i; j < array.size(); j++) {

                    if (!ePrimeiro(array.get(i), array.get(j))) {
                        Cliente temp = array.get(j);
                        array.set(j, array.get(i));
                        array.set(i, temp);
                    }
                }
            }
            return array.iterator();
        } catch (Exception erro) {
            throw erro;
        }
    }

}
