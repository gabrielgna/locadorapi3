package Persistencias;

import Entidades.Devolucao;
import Entidades.Filme;
import Entidades.Pedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PDevolucao {

    public void incluir(Devolucao devolucao) throws SQLException {

        //Cria a instrução SQL para a inserção no banco
        String sql = "INSERT INTO devolucao (data, valor,id_cliente,idfilmes) "
                + " VALUES(now(),?,?,?);";

        //Criando o objeto para a conexao
        Connection cnn = util.Conexao.getConexao();

        //Cria o objeto para executar os comandos no banco
        PreparedStatement prd = cnn.prepareStatement(sql);

        //Substitui as variveis do sql pelos valores passados
        //como parametro
        prd.setDouble(1, devolucao.getValorTotal());
        prd.setInt(2, devolucao.getCliente().getId());
        prd.setString(3, devolucao.getIdFilmes());
        //Executa o comando
        prd.execute();

        //Recupera o id gerado
        String sql2 = "SELECT currval('devolucao_id_seq') as id";

        Statement stm = cnn.createStatement();
        ResultSet rs = stm.executeQuery(sql2);

        if (rs.next()) {
            devolucao.setId(rs.getInt("id"));
        }

        rs.close();
        cnn.close();

    }

    public List<Devolucao> listar() throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM devolucao";

        Statement stm = cnn.createStatement();

        ResultSet rs = stm.executeQuery(sql);

        List<Devolucao> lista = new ArrayList<>();

        while (rs.next()) {
            Devolucao devolucao = new Devolucao();
            devolucao.setId(rs.getInt("id"));
            devolucao.setData(rs.getDate("data"));
            devolucao.setValorTotal(rs.getDouble("valor"));
            devolucao.setIdFilmes(rs.getString("idfilmes"));
            devolucao.setCliente(new PCliente().consultar(rs.getInt("id_cliente")));
            lista.add(devolucao);
        }
        rs.close();
        cnn.close();

        return lista;
    }

    public List<Devolucao> listarPorCliente(int idcliente) throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM devolucao WHERE id_cliente = ?";

        PreparedStatement stm = cnn.prepareStatement(sql);
        
        stm.setInt(1, idcliente);

        ResultSet rs = stm.executeQuery();

        List<Devolucao> lista = new ArrayList<>();

        while (rs.next()) {
            Devolucao devolucao = new Devolucao();
            devolucao.setId(rs.getInt("id"));
            devolucao.setData(rs.getDate("data"));
            devolucao.setValorTotal(rs.getDouble("valor"));
            devolucao.setIdFilmes(rs.getString("idfilmes"));
            devolucao.setCliente(new PCliente().consultar(rs.getInt("id_cliente")));
            lista.add(devolucao);
        }
        rs.close();
        cnn.close();

        return lista;
    }
}
