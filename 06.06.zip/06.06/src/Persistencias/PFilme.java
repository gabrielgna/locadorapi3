/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencias;

import Entidades.Filme;
import Entidades.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jorgin
 */
public class PFilme {

    public void incluir(Filme parametro) throws SQLException {

        //Cria a instrução SQL para a inserção no banco
        String sql = "INSERT INTO filme (nome, autor, datalancamento, valoraluguel, valorvenda, pvenda,"
                + " paluguel, datavenda, acontecimento, disponivel)"
                + " VALUES(?,?,?,?,?,?,?,?,?,?);";

        //Criando o objeto para a conexao
        Connection cnn = util.Conexao.getConexao();

        //Cria o objeto para executar os comandos no banco
        PreparedStatement prd = cnn.prepareStatement(sql);

        //Substitui as variveis do sql pelos valores passados
        //como parametro
        prd.setString(1, parametro.getNome());
        prd.setString(2, parametro.getAutor());
        prd.setString(3, parametro.getDatalancamento());
        prd.setDouble(4, parametro.getValoraluguel());
        prd.setDouble(5, parametro.getValorvenda());
        prd.setString(6, parametro.getPvenda());
        prd.setString(7, parametro.getPalguel());
        prd.setString(8, parametro.getDatavenda());
        prd.setString(9, parametro.getAcontecimento());
        prd.setString(10, parametro.getDisponivel());

        //Executa o comando
        prd.execute();

        //Recupera o id gerado
        String sql2 = "SELECT currval('filme_id_seq') as id";

        Statement stm = cnn.createStatement();
        ResultSet rs = stm.executeQuery(sql2);

        if (rs.next()) {
            parametro.setId(rs.getInt("id"));
        }

        rs.close();
        cnn.close();

    }

    public void alterarNaoDisponivel(int id) throws SQLException {

        String sql = "UPDATE filme SET" + " disponivel = 'NAO'"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, id);

        prd.execute();
        cnn.close();

    }

    public void Reserva(int id, int idcliente) throws SQLException {

        String sql = "UPDATE filme SET" + " ReservadoPara = ?"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, idcliente);
        prd.setInt(2, id);

        prd.execute();
        cnn.close();

    }

    public void Devolucao(int id) throws SQLException {

        String sql = "UPDATE filme SET" + " disponivel = 'SIM', id_cliente_aluguel = 0, diascontratados = 0 "
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, id);

        prd.execute();
        cnn.close();

    }

    public void alterarDiariasContratadasEidCliente(int id, int dias, int idcliente) throws SQLException {

        String sql = "UPDATE filme SET" + " diascontratados = ? , id_cliente_aluguel = ?"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, dias);
        prd.setInt(2, idcliente);
        prd.setInt(3, id);

        prd.execute();
        cnn.close();

    }

    public void alterar(Funcionario parametro) throws SQLException {

        String sql = "UPDATE clientes SET"
                + " nome = ?, cpf = ?, sexo = ?, usuario = ?, senha = ?, email = ?"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setString(1, parametro.getNome());
        prd.setString(2, parametro.getCpf());
        prd.setString(3, parametro.getSexo());
        prd.setString(4, parametro.getUsuario());
        prd.setString(5, parametro.getSenha());
        prd.setString(6, parametro.getEmail());

        prd.execute();
        cnn.close();

    }

    public void excluir(int id) throws SQLException {

        String sql = "DELETE FROM clientes"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, id);

        prd.execute();
        cnn.close();

    }

    public Filme consultar(int id) throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT *" + " FROM filme " + " WHERE id = ?";

        PreparedStatement stm = cnn.prepareStatement(sql);
        stm.setInt(1, id);

        ResultSet rs = stm.executeQuery();

        Filme filme = new Filme();
        if (rs.next()) {
            filme.setId(rs.getInt("id"));
            filme.setNome(rs.getString("nome"));
            filme.setAutor(rs.getString("autor"));
            filme.setDatalancamento(rs.getString("datalancamento"));
            filme.setValoraluguel(rs.getDouble("valoraluguel"));
            filme.setValorvenda(rs.getDouble("valorvenda"));
            filme.setPvenda(rs.getString("pvenda"));
            filme.setPalguel(rs.getString("paluguel"));
            filme.setDatavenda(rs.getString("datavenda"));
            filme.setAcontecimento(rs.getString("acontecimento"));
            filme.setDisponivel(rs.getString("disponivel"));
            filme.setId_cliente_aluguel(rs.getInt("id_cliente_aluguel"));

        }
        rs.close();
        cnn.close();

        return filme;
    }

    public List<Filme> ListarNome(Filme parametro) throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM filme WHERE 1=1 ";

        if (parametro.getNome() != null) {

            if (!parametro.getNome().isEmpty()) {
                sql += " and upper(nome) like ?";
            }
        }

        PreparedStatement prd = cnn.prepareStatement(sql);

        if (parametro.getNome() != null) {
            if (!parametro.getNome().isEmpty()) {
                prd.setString(1, "%" + parametro.getNome().toUpperCase() + "%");
            }
        }

        ResultSet rs = prd.executeQuery();
        List<Filme> lista = new ArrayList<>();

        while (rs.next()) {
            Filme filme = new Filme();
            filme.setId(rs.getInt("id"));
            filme.setNome(rs.getString("nome"));
            filme.setAutor(rs.getString("autor"));
            filme.setDatalancamento(rs.getString("datalancamento"));
            filme.setValoraluguel(rs.getDouble("valoraluguel"));
            filme.setValorvenda(rs.getDouble("valorvenda"));
            filme.setPvenda(rs.getString("pvenda"));
            filme.setPalguel(rs.getString("paluguel"));
            filme.setDatavenda(rs.getString("datavenda"));
            filme.setAcontecimento(rs.getString("acontecimento"));
            filme.setDisponivel(rs.getString("disponivel"));
            filme.setId_cliente_aluguel(rs.getInt("id_cliente_aluguel"));
            lista.add(filme);
        }
        rs.close();
        cnn.close();

        return lista;
    }

    public List<Filme> listarNomeAutor(Filme parametro) throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM filme WHERE 1=1 ";

        if (parametro.getAutor() != null) {

            if (!parametro.getAutor().isEmpty()) {
                sql += " and upper(autor) like ?";
            }
        }

        PreparedStatement prd = cnn.prepareStatement(sql);

        if (parametro.getAutor() != null) {
            if (!parametro.getAutor().isEmpty()) {
                prd.setString(1, "%" + parametro.getAutor().toUpperCase() + "%");
            }
        }

        ResultSet rs = prd.executeQuery();
        List<Filme> lista = new ArrayList<>();

        while (rs.next()) {
            Filme filme = new Filme();
            filme.setId(rs.getInt("id"));
            filme.setNome(rs.getString("nome"));
            filme.setAutor(rs.getString("autor"));
            filme.setDatalancamento(rs.getString("datalancamento"));
            filme.setValoraluguel(rs.getDouble("valoraluguel"));
            filme.setValorvenda(rs.getDouble("valorvenda"));
            filme.setPvenda(rs.getString("pvenda"));
            filme.setPalguel(rs.getString("paluguel"));
            filme.setDatavenda(rs.getString("datavenda"));
            filme.setAcontecimento(rs.getString("acontecimento"));
            filme.setDisponivel(rs.getString("disponivel"));
            filme.setId_cliente_aluguel(rs.getInt("id_cliente_aluguel"));
            lista.add(filme);
        }
        rs.close();
        cnn.close();

        return lista;
    }

    public List<Filme> listarParaVenda() throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM filme WHERE pvenda='SIM' AND disponivel='SIM'";

        Statement stm = cnn.createStatement();

        ResultSet rs = stm.executeQuery(sql);

        List<Filme> lista = new ArrayList<>();

        while (rs.next()) {
            Filme filme = new Filme();
            filme.setId(rs.getInt("id"));
            filme.setNome(rs.getString("nome"));
            filme.setAutor(rs.getString("autor"));
            filme.setDatalancamento(rs.getString("datalancamento"));
            filme.setValoraluguel(rs.getDouble("valoraluguel"));
            filme.setValorvenda(rs.getDouble("valorvenda"));
            filme.setPvenda(rs.getString("pvenda"));
            filme.setPalguel(rs.getString("paluguel"));
            filme.setDatavenda(rs.getString("datavenda"));
            filme.setAcontecimento(rs.getString("acontecimento"));
            filme.setDisponivel(rs.getString("disponivel"));
            filme.setId_cliente_aluguel(rs.getInt("id_cliente_aluguel"));
            lista.add(filme);
        }
        rs.close();
        cnn.close();

        return lista;
    }

    public List<Filme> listarParaAluguel() throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM filme WHERE paluguel='SIM' AND disponivel='SIM'";

        Statement stm = cnn.createStatement();

        ResultSet rs = stm.executeQuery(sql);

        List<Filme> lista = new ArrayList<>();

        while (rs.next()) {
            Filme filme = new Filme();
            filme.setId(rs.getInt("id"));
            filme.setNome(rs.getString("nome"));
            filme.setAutor(rs.getString("autor"));
            filme.setDatalancamento(rs.getString("datalancamento"));
            filme.setValoraluguel(rs.getDouble("valoraluguel"));
            filme.setValorvenda(rs.getDouble("valorvenda"));
            filme.setPvenda(rs.getString("pvenda"));
            filme.setPalguel(rs.getString("paluguel"));
            filme.setDatavenda(rs.getString("datavenda"));
            filme.setAcontecimento(rs.getString("acontecimento"));
            filme.setDisponivel(rs.getString("disponivel"));
            filme.setId_cliente_aluguel(rs.getInt("id_cliente_aluguel"));
            filme.setDiasContratados(rs.getInt("diascontratados"));
            lista.add(filme);
        }
        rs.close();
        cnn.close();

        return lista;
    }

    public List<Filme> listaAsocciadaAoCliente(int idCliente) throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM filme WHERE id_cliente_aluguel = ? ";

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, idCliente);

        ResultSet rs = prd.executeQuery();

        List<Filme> lista = new ArrayList<>();

        while (rs.next()) {
            Filme filme = new Filme();
            filme.setId(rs.getInt("id"));
            filme.setNome(rs.getString("nome"));
            filme.setAutor(rs.getString("autor"));
            filme.setDatalancamento(rs.getString("datalancamento"));
            filme.setValoraluguel(rs.getDouble("valoraluguel"));
            filme.setValorvenda(rs.getDouble("valorvenda"));
            filme.setPvenda(rs.getString("pvenda"));
            filme.setPalguel(rs.getString("paluguel"));
            filme.setDatavenda(rs.getString("datavenda"));
            filme.setAcontecimento(rs.getString("acontecimento"));
            filme.setDisponivel(rs.getString("disponivel"));
            filme.setId_cliente_aluguel(rs.getInt("id_cliente_aluguel"));
            filme.setDiasContratados(rs.getInt("diascontratados"));
            lista.add(filme);
        }
        rs.close();
        cnn.close();

        return lista;
    }

    public List<Filme> listarParaReservar() throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM filme WHERE paluguel='SIM' AND disponivel='NAO'";

        Statement stm = cnn.createStatement();

        ResultSet rs = stm.executeQuery(sql);

        List<Filme> lista = new ArrayList<>();

        while (rs.next()) {
            Filme filme = new Filme();
            filme.setId(rs.getInt("id"));
            filme.setNome(rs.getString("nome"));
            filme.setAutor(rs.getString("autor"));
            filme.setDatalancamento(rs.getString("datalancamento"));
            filme.setValoraluguel(rs.getDouble("valoraluguel"));
            filme.setValorvenda(rs.getDouble("valorvenda"));
            filme.setPvenda(rs.getString("pvenda"));
            filme.setPalguel(rs.getString("paluguel"));
            filme.setDatavenda(rs.getString("datavenda"));
            filme.setAcontecimento(rs.getString("acontecimento"));
            filme.setDisponivel(rs.getString("disponivel"));
            filme.setId_cliente_aluguel(rs.getInt("id_cliente_aluguel"));
            filme.setDiasContratados(rs.getInt("diascontratados"));
            lista.add(filme);
        }
        rs.close();
        cnn.close();

        return lista;
    }

}
