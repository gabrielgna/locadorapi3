package Persistencias;

import Entidades.Cliente;
import java.sql.SQLException;

public class AdapterCliente {
    
public void Adaptar(String x) throws SQLException{
    String tudo [] = x.split(";");
    Cliente cliente = new Cliente();
    cliente.setNome(tudo[0]);
    cliente.setEndereco(tudo[1]);
    cliente.setTelefone(tudo[2]);
    cliente.setCpf(tudo[3]);
    cliente.setEmail(tudo[4]);
    cliente.setDatadenascimento(tudo[5]);
    cliente.setSexo(tudo[6]);
    new PCliente().incluir(cliente);
}
}
