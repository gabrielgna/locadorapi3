package Persistencias;

import Entidades.Cliente;

public class OrdenadoPorName extends PClienteTemplate {

    @Override
    public boolean ePrimeiro(Cliente cliente1, Cliente cliente2) {
        if (cliente1.getNome().compareToIgnoreCase(cliente2.getNome()) <= 0) {
            return true;
        } else {
            return false;
        }
    }

}
