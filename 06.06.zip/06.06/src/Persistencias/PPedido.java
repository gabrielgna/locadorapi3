package Persistencias;

import Entidades.Filme;
import Entidades.Pedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PPedido {

    public void incluir(Pedido pedido) throws SQLException {

        //Cria a instrução SQL para a inserção no banco
        String sql = "INSERT INTO pedido (data, valor,id_cliente) "
                + " VALUES(now(),?,?);";

        //Criando o objeto para a conexao
        Connection cnn = util.Conexao.getConexao();

        //Cria o objeto para executar os comandos no banco
        PreparedStatement prd = cnn.prepareStatement(sql);

        //Substitui as variveis do sql pelos valores passados
        //como parametro
        prd.setDouble(1, pedido.getValorTotal());
        prd.setInt(2, pedido.getCliente().getId());

        //Executa o comando
        prd.execute();

        //Recupera o id gerado
        String sql2 = "SELECT currval('pedido_id_seq') as id";

        Statement stm = cnn.createStatement();
        ResultSet rs = stm.executeQuery(sql2);

        if (rs.next()) {
            pedido.setId(rs.getInt("id"));
        }

        rs.close();
        cnn.close();

    }

    public List<Pedido> listar() throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT * FROM pedido";

        Statement stm = cnn.createStatement();

        ResultSet rs = stm.executeQuery(sql);

        List<Pedido> lista = new ArrayList<>();

        while (rs.next()) {
            Pedido pedido = new Pedido();
            pedido.setId(rs.getInt("id"));
            pedido.setData(rs.getDate("data"));
            pedido.setValorTotal(rs.getDouble("valor"));
            pedido.setCliente(new PCliente().consultar(rs.getInt("id_cliente")));
            lista.add(pedido);
        }
        rs.close();
        cnn.close();

        return lista;
    }

}
