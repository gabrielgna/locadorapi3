/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencias;

import Entidades.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Jorgin
 */
public class PFuncionarios {

    public void incluir(Funcionario parametro) throws SQLException {

        //Cria a instrução SQL para a inserção no banco
        String sql = "INSERT INTO funcionario (nome, cpf, sexo, usuario, senha, email) "
                + " VALUES(?,?,?,?,?,?);";

        //Criando o objeto para a conexao
        Connection cnn = util.Conexao.getConexao();

        //Cria o objeto para executar os comandos no banco
        PreparedStatement prd = cnn.prepareStatement(sql);

        //Substitui as variveis do sql pelos valores passados
        //como parametro
        prd.setString(1, parametro.getNome());
        prd.setString(2, parametro.getCpf());
        prd.setString(3, parametro.getSexo());
        prd.setString(4, parametro.getUsuario());
        prd.setString(5, parametro.getSenha());
        prd.setString(6, parametro.getEmail());

        //Executa o comando
        prd.execute();

        //Recupera o id gerado
        String sql2 = "SELECT currval('funcionario_id_seq') as id";

        Statement stm = cnn.createStatement();
        ResultSet rs = stm.executeQuery(sql2);

        if (rs.next()) {
            parametro.setId(rs.getInt("id"));
        }

        rs.close();
        cnn.close();

    }

    public void alterar(Funcionario parametro) throws SQLException {

        String sql = "UPDATE clientes SET"
                + " nome = ?, cpf = ?, sexo = ?, usuario = ?, senha = ?, email = ?"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setString(1, parametro.getNome());
        prd.setString(2, parametro.getCpf());
        prd.setString(3, parametro.getSexo());
        prd.setString(4, parametro.getUsuario());
        prd.setString(5, parametro.getSenha());
        prd.setString(6, parametro.getEmail());

        prd.execute();
        cnn.close();

    }

    public void excluir(int id) throws SQLException {

        String sql = "DELETE FROM clientes"
                + " WHERE id = ?";

        Connection cnn = util.Conexao.getConexao();

        PreparedStatement prd = cnn.prepareStatement(sql);

        prd.setInt(1, id);

        prd.execute();
        cnn.close();

    }

    public Funcionario consultar(int id) throws SQLException {

        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT id, nome, cpf, sexo, usuario, senha, email"
                + " FROM clientes "
                + " WHERE id = ?";

        PreparedStatement stm = cnn.prepareStatement(sql);
        stm.setInt(1, id);

        ResultSet rs = stm.executeQuery();

        Funcionario cliente = new Funcionario();
        if (rs.next()) {
            cliente.setId(rs.getInt("id"));
            cliente.setNome(rs.getString("nome"));
            cliente.setCpf(rs.getString("cpf"));
            cliente.setSexo(rs.getString("sexo"));
            cliente.setUsuario(rs.getString("usuario"));
            cliente.setSenha(rs.getString("senha"));
            cliente.setEmail(rs.getString("email"));

        }
        rs.close();
        cnn.close();

        return cliente;
    }
    
 public boolean Login(String login, String senha) throws SQLException {
        Connection cnn = util.Conexao.getConexao();

        String sql = "SELECT usuario, senha "
                + " FROM funcionario "
                + " WHERE usuario=? AND senha=?";

        PreparedStatement stm = cnn.prepareStatement(sql);

        stm.setString(1, login);
        stm.setString(2, senha);
        ResultSet rs = stm.executeQuery();

        if (rs.next()) {
            System.out.println("achou");
            return true;
            
        }
        rs.close();
        cnn.close();

        return false;

    }
}
